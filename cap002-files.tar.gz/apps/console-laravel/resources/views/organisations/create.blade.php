@extends('layouts.console')
@section('title', 'Nouvelle organisation')
@section('content')
<nav class="breadcrumbs"><a href="{{ route('console.organisations.index') }}">Organisations</a><span>/</span><span>Nouvelle</span></nav>
<section class="page-heading"><div><p class="eyebrow">Inscription gouvernée</p><h1>Enregistrer une organisation</h1><p class="page-heading__summary">La fiche restera en préparation jusqu’à une activation explicite. L’identité GAMAD doit déjà exister et être de type organisation.</p></div></section>
@if($errors->any())<div class="form-error" role="alert">{{ $errors->first() }}</div>@endif
<section class="card" style="margin-top:22px"><div class="card__body">
<form method="POST" action="{{ route('console.organisations.store') }}" class="form-layout">@csrf
<div class="help-callout"><strong>Information importante</strong><p>Déclarer une personne comme dirigeant se fera plus tard dans la fiche. Cette déclaration ne lui donnera aucun pouvoir automatique.</p></div>
<div class="field"><label for="denomination_officielle">Dénomination officielle</label><input class="input" id="denomination_officielle" name="denomination_officielle" value="{{ old('denomination_officielle') }}" required></div>
<div class="field"><label for="reference">Référence de la fiche</label><input class="input" id="reference" name="reference" value="{{ old('reference') }}" placeholder="ORG-GAMAD-000001" required><p class="field-help">Référence stable de la fiche, différente de l’identité canonique.</p></div>
<div class="field"><label for="identite_reference">Identité canonique</label><input class="input" id="identite_reference" name="identite_reference" value="{{ old('identite_reference') }}" placeholder="IDN-ORG-..." required></div>
<div class="field"><label for="type_reference">Type d’organisation</label><select class="input" id="type_reference" name="type_reference" required>@foreach($types as $v)<option value="{{ $v }}">{{ str_replace('_',' ',mb_strtolower($v)) }}</option>@endforeach</select></div>
<div class="field"><label for="forme_reference">Forme</label><select class="input" id="forme_reference" name="forme_reference"><option value="">Non renseignée</option>@foreach($formes as $v)<option value="{{ $v }}">{{ str_replace('_',' ',mb_strtolower($v)) }}</option>@endforeach</select></div>
<div class="field"><label for="personnalite_juridique">Personnalité juridique</label><select class="input" id="personnalite_juridique" name="personnalite_juridique" required><option value="1">Oui</option><option value="0">Non ou non vérifiée</option></select></div>
<div class="field"><label for="proprietaire_reference">Responsable de la fiche</label><input class="input" id="proprietaire_reference" name="proprietaire_reference" value="{{ old('proprietaire_reference','AUT-GAMAD-001') }}" required></div>
<div class="field"><label for="source_reference">Source</label><input class="input" id="source_reference" name="source_reference" value="{{ old('source_reference') }}" required></div>
<div class="field"><label for="classification_reference">Visibilité</label><select class="input" id="classification_reference" name="classification_reference" required>@foreach($classifications as $v)<option value="{{ $v }}">{{ str_replace('_',' ',mb_strtolower($v)) }}</option>@endforeach</select></div>
<div class="field"><label for="nom_court">Nom court</label><input class="input" id="nom_court" name="nom_court" value="{{ old('nom_court') }}"></div>
<div class="field"><label for="nom_commercial">Nom commercial</label><input class="input" id="nom_commercial" name="nom_commercial" value="{{ old('nom_commercial') }}"></div>
<div class="field"><label for="description">Description</label><textarea class="input" id="description" name="description" rows="4">{{ old('description') }}</textarea></div>
<div><button class="button button--primary" type="submit">Enregistrer en préparation</button></div>
</form></div></section>
@endsection
