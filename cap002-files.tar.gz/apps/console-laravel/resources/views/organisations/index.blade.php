@extends('layouts.console')
@section('title', 'Organisations')
@section('content')
<section class="page-heading">
    <div>
        <p class="eyebrow">Organisation de GAMAD</p>
        <h1>Organisations</h1>
        <p class="page-heading__summary">Entreprises, associations, institutions et structures reconnues par GAMAD. Une organisation possède toujours une identité canonique distincte.</p>
    </div>
    @if($autorite)<a class="button button--primary" href="{{ route('console.organisations.create') }}">Enregistrer une organisation</a>@endif
</section>

@if($indisponible)
<div class="alert alert--danger"><span class="alert__dot"></span><span><strong class="alert__title">Registre indisponible</strong><span class="alert__detail">Aucune information n’est présumée. Réessayez après rétablissement.</span></span></div>
@endif

<section class="human-summary" style="margin-top:22px">
    <div><h2 class="human-summary__title">À quoi sert cet écran ?</h2><p class="human-summary__copy">Il montre quelles organisations GAMAD reconnaît, leur état, leur structure et leurs affiliations. Être déclaré dirigeant ou représentant ne suffit jamais à prouver un pouvoir de signature : un mandat valide est vérifié séparément.</p></div>
    <dl class="human-facts">
        <div class="human-fact"><dt>Organisations visibles</dt><dd>{{ count($organisations) }}</dd></div>
        <div class="human-fact"><dt>Action sensible</dt><dd>Activation par l’autorité</dd></div>
        <div class="human-fact"><dt>Règle de sécurité</dt><dd>Affiliation ≠ mandat</dd></div>
    </dl>
</section>

<section class="card" style="margin-top:22px">
    <div class="card__header"><div><h2 class="card__title">Rechercher</h2><p class="card__description">Filtrez sans utiliser les références techniques.</p></div></div>
    <div class="card__body">
        <form method="GET" class="form-layout" style="grid-template-columns:repeat(3,minmax(0,1fr));display:grid;gap:14px">
            <div class="field"><label for="etat">Situation</label><select class="input" id="etat" name="etat"><option value="">Toutes</option>@foreach($etats as $v)<option value="{{ $v }}" @selected(request('etat')===$v)>{{ str_replace('_',' ',mb_strtolower($v)) }}</option>@endforeach</select></div>
            <div class="field"><label for="type">Type</label><select class="input" id="type" name="type"><option value="">Tous</option>@foreach($types as $v)<option value="{{ $v }}" @selected(request('type')===$v)>{{ str_replace('_',' ',mb_strtolower($v)) }}</option>@endforeach</select></div>
            <div class="field"><label for="classification">Visibilité</label><select class="input" id="classification" name="classification"><option value="">Toutes</option>@foreach($classifications as $v)<option value="{{ $v }}" @selected(request('classification')===$v)>{{ str_replace('_',' ',mb_strtolower($v)) }}</option>@endforeach</select></div>
            <div><button class="button button--secondary" type="submit">Appliquer les filtres</button></div>
        </form>
    </div>
</section>

<section class="card" style="margin-top:22px">
    <div class="card__header"><div><h2 class="card__title">Organisations reconnues</h2><p class="card__description">Ouvrez une fiche pour voir sa structure, ses membres déclarés et les pouvoirs réellement vérifiés.</p></div></div>
    <div class="card__body">
        <div class="identity-list">
        @forelse($organisations as $o)
            <a class="identity-row" href="{{ route('console.organisations.show', $o['reference']) }}">
                <span class="identity-main"><span class="identity-avatar" aria-hidden="true">{{ mb_substr($o['revision']['denomination_officielle'] ?? 'OR',0,2) }}</span><span><span class="identity-name">{{ $o['revision']['denomination_officielle'] ?? 'Organisation sans dénomination' }}</span><span class="card__description">{{ str_replace('_',' ',mb_strtolower($o['type_reference'])) }}</span></span></span>
                <span><span class="status {{ $o['etat']==='ACTIVE' ? 'status--success' : 'status--warning' }}">{{ str_replace('_',' ',mb_strtolower($o['etat'] ?? 'inconnue')) }}</span></span>
                <span aria-hidden="true">→</span>
            </a>
        @empty
            <div class="empty-state"><h2>Aucune organisation visible</h2><p>Aucune fiche ne correspond aux filtres ou le registre n’a pas encore été initialisé.</p></div>
        @endforelse
        </div>
    </div>
</section>
@endsection
