<?php

declare(strict_types=1);

use App\Http\Controllers\Api\V1\OrganisationController;
use Illuminate\Support\Facades\Route;

Route::middleware('gamad.api')->group(function (): void {
    Route::get('/organisations', [OrganisationController::class, 'index']);
    Route::post('/organisations', [OrganisationController::class, 'store'])->middleware('throttle:20,1');
    Route::get('/organisations/{reference}', [OrganisationController::class, 'show']);
    Route::patch('/organisations/{reference}', [OrganisationController::class, 'update'])->middleware('throttle:20,1');
    foreach (['activation','suspension','dissolution','retrait'] as $transition) {
        Route::post("/organisations/{reference}/{$transition}", [OrganisationController::class, 'transition'])
            ->defaults('transition', $transition)->middleware('throttle:20,1');
    }
    Route::get('/organisations/{reference}/identifiants', [OrganisationController::class, 'identifiants']);
    Route::post('/organisations/{reference}/identifiants', [OrganisationController::class, 'declarerIdentifiant'])->middleware('throttle:20,1');
    Route::post('/organisations/{reference}/identifiants/{id}/fermeture', [OrganisationController::class, 'fermerIdentifiant'])->whereNumber('id')->middleware('throttle:20,1');
    Route::get('/organisations/{reference}/structure', [OrganisationController::class, 'structure']);
    Route::get('/organisations/{reference}/unites', [OrganisationController::class, 'structure']);
    Route::post('/organisations/{reference}/unites', [OrganisationController::class, 'creerUnite'])->middleware('throttle:20,1');
    Route::post('/organisations/{reference}/unites/{unite}/deplacement', [OrganisationController::class, 'deplacerUnite'])->middleware('throttle:20,1');
    Route::post('/organisations/{reference}/unites/{unite}/fermeture', [OrganisationController::class, 'fermerUnite'])->middleware('throttle:20,1');
    Route::get('/organisations/{reference}/relations', [OrganisationController::class, 'relations']);
    Route::post('/organisations/{reference}/relations', [OrganisationController::class, 'declarerRelation'])->middleware('throttle:20,1');
    Route::post('/organisations/{reference}/relations/{relation}/fermeture', [OrganisationController::class, 'fermerRelation'])->middleware('throttle:20,1');
    Route::get('/organisations/{reference}/affiliations', [OrganisationController::class, 'affiliations']);
    Route::post('/organisations/{reference}/affiliations', [OrganisationController::class, 'proposerAffiliation'])->middleware('throttle:20,1');
    foreach (['activation','suspension','fermeture'] as $transition) {
        Route::post("/organisations/{reference}/affiliations/{affiliation}/{$transition}", [OrganisationController::class, 'transitionAffiliation'])
            ->defaults('transition', $transition)->middleware('throttle:20,1');
    }
    Route::get('/organisations/{reference}/fonctions', [OrganisationController::class, 'fonctions']);
    Route::post('/organisations/{reference}/fonctions', [OrganisationController::class, 'creerFonction'])->middleware('throttle:20,1');
    Route::get('/identites/{identite}/organisations', [OrganisationController::class, 'affiliationsIdentite']);
    Route::post('/organisations/{reference}/appartenance/verification', [OrganisationController::class, 'verifierAppartenance'])->middleware('throttle:60,1');
    Route::post('/organisations/{reference}/representation/verification', [OrganisationController::class, 'verifierRepresentation'])->middleware('throttle:60,1');
});
