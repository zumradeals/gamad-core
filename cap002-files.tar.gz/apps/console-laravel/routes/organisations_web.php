<?php

declare(strict_types=1);

use App\Http\Controllers\OrganisationConsoleController;
use Illuminate\Support\Facades\Route;

Route::prefix('organisations')->name('console.organisations.')->group(function (): void {
    Route::get('/', [OrganisationConsoleController::class, 'index'])->name('index');
    Route::get('/nouvelle', [OrganisationConsoleController::class, 'create'])->name('create');
    Route::post('/', [OrganisationConsoleController::class, 'store'])->name('store');
    Route::get('/{reference}', [OrganisationConsoleController::class, 'show'])->name('show');
    foreach (['activation','suspension','dissolution','retrait'] as $transition) {
        Route::post("/{reference}/{$transition}", [OrganisationConsoleController::class, 'transition'])
            ->defaults('transition', $transition)->name($transition);
    }
    Route::post('/{reference}/unites', [OrganisationConsoleController::class, 'creerUnite'])->name('unites.creer');
    Route::post('/{reference}/affiliations', [OrganisationConsoleController::class, 'proposerAffiliation'])->name('affiliations.proposer');
    foreach (['activation','suspension','fermeture'] as $transition) {
        Route::post("/{reference}/affiliations/{affiliation}/{$transition}", [OrganisationConsoleController::class, 'transitionAffiliation'])
            ->defaults('transition', $transition)->name("affiliations.{$transition}");
    }
    Route::post('/{reference}/representation', [OrganisationConsoleController::class, 'verifierRepresentation'])->name('representation');
});
