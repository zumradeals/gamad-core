<?php

declare(strict_types=1);

/** Intégration structurelle API v1 de CAP-CORE-002. */
$racine=dirname(__DIR__,4);
$routes=file_get_contents($racine.'/apps/console-laravel/routes/organisations_api.php') ?: '';
$controleur=file_get_contents($racine.'/apps/console-laravel/app/Http/Controllers/Api/V1/OrganisationController.php') ?: '';
$acces=file_get_contents($racine.'/apps/console-laravel/app/Application/Organisations/AccesOrganisations.php') ?: '';
$attendus=['/organisations','/identites/{identite}/organisations','appartenance/verification','representation/verification','affiliations','unites','relations','fonctions'];
$echecs=0;echo "INTÉGRATION — API ORGANISATIONS V1 (CAP-CORE-002)\n\n";
foreach($attendus as $v){$ok=str_contains($routes,$v);echo $ok?"  [OK]    route {$v}\n":"  [ÉCHEC] route {$v}\n";$echecs+=!$ok;}
$verifs=[
    'le sujet vient de la session'=>str_contains($controleur,"attributes->get('gamad_entite')"),
    'aucun champ de gouvernance n’est validé depuis le corps'=>!preg_match("/'(politique|preuve|producteur)'\s*=>/",$controleur),
    'CAP-CORE-004 précède les écritures'=>str_contains($acces,'new Ctr03')&&str_contains($acces,'$operation($registre, $dossier)'),
    'CAP-CORE-013 conserve la décision et le résultat'=>str_contains($acces,"'categorie' => 'ORGANISATIONS'")&&substr_count($acces,'$journal->enregistrer')>=2,
    'aucune écriture SQL dans les contrôleurs'=>!str_contains($controleur,'->prepare(')&&!str_contains($controleur,'->exec('),
    'la représentation dispose de son opération explicite'=>str_contains($controleur,'verifierRepresentation')&&str_contains($routes,'representation/verification'),
];
foreach($verifs as $libelle=>$ok){echo $ok?"  [OK]    {$libelle}\n":"  [ÉCHEC] {$libelle}\n";$echecs+=!$ok;}
echo "\n".($echecs===0?'API organisations v1 : ÉTABLIE.':'API organisations v1 : NON ÉTABLIE.')."\n";exit($echecs===0?0:1);
