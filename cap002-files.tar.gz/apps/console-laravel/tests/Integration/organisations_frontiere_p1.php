<?php

declare(strict_types=1);

/** Frontière CAP-CORE-001 / CAP-CORE-002 / CAP-CORE-003. */
$racine=dirname(__DIR__,4);
$registre=file_get_contents($racine.'/core/registre-organisations/src/LectureOrganisations.php') ?: '';
$schema=file_get_contents($racine.'/core/registre-organisations/src/SchemaOrganisations.php') ?: '';
$ctr01=file_get_contents($racine.'/core/registre-identites/src/Ctr01.php') ?: '';
$echecs=0;echo "INTÉGRATION — FRONTIÈRE ORGANISATIONS P1\n\n";
$verifs=[
    'CAP-CORE-002 conserve une identité canonique unique'=>str_contains($schema,'identite_reference TEXT NOT NULL UNIQUE'),
    'le schéma ne duplique aucun secret'=>!preg_match('/password|mot_de_passe|secret|token/i',$schema),
    'la représentation appelle CAP-CORE-003'=>str_contains($registre,'resoudreMandat('),
    'l’affiliation seule ne rend jamais opposable'=>str_contains($registre,"'MANDAT_ABSENT'")&&str_contains($registre,"'opposable' => $opposable"),
    'CAP-CORE-001 annonce la délégation organisationnelle'=>str_contains($ctr01,'CAP-CORE-002'),
];
foreach($verifs as $libelle=>$ok){echo $ok?"  [OK]    {$libelle}\n":"  [ÉCHEC] {$libelle}\n";$echecs+=!$ok;}
echo "\n".($echecs===0?'Frontière CAP-CORE-002 : ÉTABLIE.':'Frontière CAP-CORE-002 : NON ÉTABLIE.')."\n";exit($echecs===0?0:1);
