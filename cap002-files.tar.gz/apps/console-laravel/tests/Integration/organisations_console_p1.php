<?php

declare(strict_types=1);

/** Contre-épreuve de compréhension de la console Organisations. */
$racine=dirname(__DIR__,4);
$index=file_get_contents($racine.'/apps/console-laravel/resources/views/organisations/index.blade.php') ?: '';
$fiche=file_get_contents($racine.'/apps/console-laravel/resources/views/organisations/show.blade.php') ?: '';
$ctrl=file_get_contents($racine.'/apps/console-laravel/app/Http/Controllers/OrganisationConsoleController.php') ?: '';
$echecs=0;echo "INTÉGRATION — CONSOLE ORGANISATIONS P1 (CAP-CORE-002)\n\n";
$verifs=[
    'la page explique son utilité au dirigeant'=>str_contains($index,'À quoi sert cet écran ?'),
    'la distinction affiliation / mandat est visible'=>str_contains($index,'Affiliation ≠ mandat')&&str_contains($fiche,'Elle ne donne ni accès applicatif ni pouvoir de signature'),
    'un contrôle humain du pouvoir est présent'=>str_contains($fiche,'Vérifier un pouvoir de représentation'),
    'les détails techniques sont repliés'=>str_contains($fiche,'Afficher les détails techniques'),
    'les actions terminales sont rangées dans une zone sensible'=>str_contains($fiche,'Actions sensibles sur l’organisation'),
    'la console appelle le même cas d’usage que l’API'=>str_contains($ctrl,'AccesOrganisations')&&!str_contains($ctrl,'->prepare('),
    'aucun booléen mandat_verifie n’est affiché comme décision'=>!str_contains($fiche,"['mandat_verifie']"),
];
foreach($verifs as $libelle=>$ok){echo $ok?"  [OK]    {$libelle}\n":"  [ÉCHEC] {$libelle}\n";$echecs+=!$ok;}
echo "\n".($echecs===0?'Console Organisations : ÉTABLIE.':'Console Organisations : NON ÉTABLIE.')."\n";exit($echecs===0?0:1);
